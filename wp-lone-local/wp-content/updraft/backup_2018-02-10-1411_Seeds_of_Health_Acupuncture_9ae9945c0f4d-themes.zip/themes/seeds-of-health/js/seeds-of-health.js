(function($) {
	
    // Theme functionality here
	
})( jQuery );
