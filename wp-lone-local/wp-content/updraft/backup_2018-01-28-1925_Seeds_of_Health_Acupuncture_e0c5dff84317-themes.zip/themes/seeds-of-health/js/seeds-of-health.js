(function($) {
	
	// You can start using $ right here for theme functions and jQuery :)
	
})( jQuery );
